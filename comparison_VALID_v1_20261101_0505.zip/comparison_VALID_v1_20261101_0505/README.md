# SIH26153 - VALID comparison export v1 (2026-11-01 05:05)
Status: provisional research results. Offline forecasting experiment. Not live, not real-time, not production-validated.

## What this is
Next-minute Bot_Pct forecast, identical 102 test targets (2018-02-03 11:18 -> 12:59), same 7 features, same 25/50 state thresholds.
Models: persistence, Random Forest (flattened windows), frozen LSTM (L=5), frozen GRU-V2 (L=5). Files: comparison_test_identical_102_targets.csv (main).

## Validity
- The earlier GRU grid (2-minute-ahead targets) is EXCLUDED and not used anywhere. GRU-V2 was built on the Phase 4 tensors verified by Gate G1
  (target = Bot_Pct(t+1), counts 312/80/102, identical val/test timestamps for every L). GRU-V2 configuration was chosen on validation only; the holdout was evaluated once.
- LSTM was regenerated from its frozen config and matched the saved Phase 4 results. This export did not retrain or re-evaluate any model.
- Random Forest L was chosen with the same validation rule (best validation RMSE +0.10, smallest L) -> L=5. RF L=15 has the best test RMSE but was NOT selected; do not use it to pick a model.
- RF Member 1 (19 features, train+val, apparently n=101) is in a separate reference file because it is not like-for-like.

## Headline (see CSV for all numbers)
GRU-V2 vs LSTM: pre-declared rule -> "comparable, no demonstrated advantage" (RMSE gap passes, MAE gap fails); exploratory paired bootstrap interval for ensemble RMSE (LSTM - GRU) includes 0.
The LSTM remains the provisional integration model. No model is declared better than the Random Forest by a demonstrated margin on one test day.

## Caveats (must be reported with any number)
- Low-state recall is ~0% for LSTM, GRU and RF on the test day (all 23 Low targets predicted Medium); persistence 17.39%. Validation Low recall was ~85%, so there is a validation-to-test shift. Averages hide this.
- Single test day, 102 targets (23 Low, 66 Medium, 13 High). Differences of a few tenths of a percentage point are within seed/bootstrap noise.
- The target at 12:59 (row 502) is retained, but its provenance is unverified (flag Unverified_1259 in the predictions CSV).
- Dataset audit incomplete: cic_ids2018_5min_windows.parquet and six "(1)" files were unavailable and NOT audited; the 16,697-flow benign gap and the 9.19 threshold remain unexplained. They affect a separate classification branch, not this protocol.
- Low recalls computed here: {"LSTM_ens_low_recall": 0.0, "GRU_ens_low_recall": 0.0, "persistence_low_recall": 17.39}
