# SIH26153 - Phase 4 LSTM, REGENERATED v1 (provisional integration model)

Regenerated copy of the frozen Phase 4 LSTM. It reproduces the saved Phase 4 test metrics (to 1e-3) but is NOT byte-identical to the original package.

## Contents
- lstm_primary_seed_42..46.keras : five models (use the 5-seed mean for the ensemble forecast)
- scaler_features.joblib / scaler_target.joblib : StandardScalers fitted on training data only
- config.json : features, order, shapes, scaler parameters, thresholds, metrics, limitations
- test_predictions_lstm_regen.csv, seed_metrics_lstm_regen.csv : evidence
- MANIFEST_sha256.txt : file hashes

## Usage
Input: 5 consecutive 1-minute rows x 7 features (order in config.json), raw units -> scaler_features.transform -> model -> scaler_target.inverse_transform -> Bot_Pct(t+1) in %.
State: Low < 25 <= Medium < 50 <= High.

## Limitations
- Low-state recall is ~0% on the test day (Low samples are predicted Medium)
- single test day, 102 targets (23 Low, 66 Medium, 13 High)
- traffic-state forecasting on a limited dataset; not proof of attack prediction, real-time detection, or generalisation to unseen attacks
- sequences must be 5 CONSECUTIVE 1-minute rows; never span a time gap
- Not a live, real-time, or production-validated system.
